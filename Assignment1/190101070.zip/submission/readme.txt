Name: Prakhar Rajpali
Roll Number: 190101070


Use g++ as the source compiler

keep source code in folder along with files in input_files folder
    program.txt -> input file
    optab.txt -> opcode file

run the folloing command:
g++ 190101070_Assign01.cpp 

then execute ./a

Four new files will be created:
1. intermediate.txt
2. symtab.txt
3. length.txt
4. output.txt 
